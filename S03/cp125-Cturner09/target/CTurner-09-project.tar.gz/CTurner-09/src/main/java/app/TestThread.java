package app;

// TODO: Auto-generated Javadoc
/**
 * The Class TestThread.
 */
public class TestThread {
	   
   	/**
   	 * The main method.
   	 *
   	 * @param args the arguments
   	 */
   	public static void main(String args[]) {

	      RunnableDemo R1 = new RunnableDemo( "Thread-1");
	      R1.start();

	      RunnableDemo R2 = new RunnableDemo( "Thread-2");
	      R2.start();
	   }
}